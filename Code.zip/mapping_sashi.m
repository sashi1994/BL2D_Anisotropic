function [map,cc]= mapping_sashi(res_stress_mises,elements,nodes, initial_size)
mimnum_stress= 1;
minimum_size=2;
%%
% [m,~]=size(res_stress_mises{1});                                            % getting number of elements
% index=find(res_stress_mises{5}(:,1)>mimnum_stress);                         % getting number of elements above limit
% c=zeros(m,2);
% percentage=(size(index,1)/m);                                               % percent of elements above limit

% for i=1:m
%     c(i,2)=elements(i,2);
%     c(i,1)=elements(i,1);
% end
% 
% n=[];                                                                       % nodes
% st=[];
% for i=1:size(index,1)
%     ss=c(i,1);
%     n=[n;ss];
%     ss=c(i,2);
%     n=[n;ss];
% end
% n=unique(n);
% 
% 
% 
% map=ones(size(p,1),1);
% map(:,1)=initial_size;
% for i=1:size(n,1)
%     map(n(i))=map(n(i))-(percentage*initial_size);
% end
%%
cc=zeros(size(nodes,1),1);                                                    % nodes and stress
map=zeros(size(nodes,1),1);                                                   % nodes and length for map
map=map+initial_size;

for i=1:size(nodes,1)
    ind1=find(elements(:,1)==i);
    ind2=find(elements(:,2)==i);
    v=[];
    for j=1:size(ind1,1)
        v=[v;(res_stress_mises{5}(ind1(j)))];
    end
    
    for j=1:size(ind2,1)
        v=[v;(res_stress_mises{5}(ind2(j)))];
    end
    v=abs(v);
    cc(i,1)=mean(v);
end

index=find(cc(:,1)>mimnum_stress);
max_stress=max(cc);

for i=1:size(map,1)
    x=cc(i);
    x0=mimnum_stress;
    y1=initial_size;
    y0=minimum_size;
    x1=max_stress;
    
    map(i)=y1-(((y1-y0)/(x1-x0))*(x-x0));
end


end