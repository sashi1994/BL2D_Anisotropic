function [map,cc]= re_mapping_sashi(res_stress_mises,elements,p,map,initial_size)
mimnum_stress= 1;
minimum_size=2;
%%
% [m,~]=size(res_stress_mises{1});                                            % getting number of elements
% index=find(res_stress_mises{5}(:,1)>mimnum_stress);                         % getting number of elements above limit
% c=zeros(m,2);
% percentage=(size(index,1)/m); 
% map_1=ones(size(p,1)-size(map,1),1);
% map_1=map_1*initial_size;
% map=[map;map_1];
% 
% for i=1:m
%     c(i,2)=elements(i,2);
%     c(i,1)=elements(i,1);
% end
%     
%     oo=[];                                                                  % nodes
%     for i=1:size(index,1)
%         ss=c(i,1);
%         oo=[oo;ss];
%         ss=c(i,2);
%         oo=[oo;ss];
%     end
%     oo=unique(oo);
%  
%     for i=1:size(oo,1)
%         map(oo(i))=map(oo(i))-(percentage*map(oo(i)));
%     end
%%
cc=zeros(size(p,1),1);                                                    % nodes and stress
map_1=ones(size(p,1)-size(map,1),1);
map_1=map_1*initial_size;
map=[map;map_1];

for i=1:size(p,1)
    ind1=find(elements(:,1)==i);
    ind2=find(elements(:,2)==i);
    v=[];
    for j=1:size(ind1,1)
        v=[v;(res_stress_mises{5}(ind1(j)))];
    end
    
    for j=1:size(ind2,1)
        v=[v;(res_stress_mises{5}(ind2(j)))];
    end
    v=abs(v);
    cc(i,1)=mean(v);
end

index=find(cc(:,1)>mimnum_stress);
max_stress=max(cc);
x0=mimnum_stress;
y0=minimum_size;
x1=max_stress;
y1=y0+(((initial_size-y0)/(3.04-x0))*(x1-x0));


for i=1:size(map,1)
    x=cc(i);
    map(i)=y1-(((y1-y0)/(x1-x0))*(x-x0));
end
end
