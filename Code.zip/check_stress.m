function stress=check_stress(res_stress_mises)
m=res_stress_mises{3}(:,1);

s=find(m(:,1)>=1);

if isvector(s)==1
    stress=1;
else 
    stress=0;
end
end