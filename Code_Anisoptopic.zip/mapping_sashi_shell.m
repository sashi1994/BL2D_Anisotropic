function [eigen]=mapping_sashi_shell(eigen,t,p,nodes,sigma_user,minimum_size)
 
node_map=zeros(size(nodes,1),1);                                                       % nodes with their length after node_mapping 
%% node_mapping formula 

for i=1:size(nodes,1)
    V=eigen(i).vector;
    D=eigen(i).value;
    sigma=abs(D);
    h_mat=zeros(2,2);
    mat=V;
    mat_trans=transpose(V);
    
% 
    if sigma(1,1)>=sigma_user
        h_mat(2,2)=minimum_size;
    else  
        h_mat(2,2)=minimum_size*(sigma_user/sigma(1,1));
        if h_mat(2,2)>1000
            h_mat(2,2)=1000;
        end
    end
    
    
    if sigma(2,2)>=sigma_user        
        h_mat(1,1)=minimum_size;
    else 
        h_mat(1,1)=minimum_size*(sigma_user/sigma(2,2));
        if h_mat(1,1)>1000
            h_mat(1,1)=1000;
        end
    end
    ff=6;
    % check form
    if h_mat(2,2)<h_mat(1,1)
%         h_mat(1,1)=1*h_mat(2,2);
        if h_mat(1,1)>ff*h_mat(2,2)
            h_mat(1,1)=ff*h_mat(2,2);
        end
    end
    if h_mat(1,1)<h_mat(2,2)
%         h_mat(2,2)=1*h_mat(1,1);
        if h_mat(2,2)>ff*h_mat(1,1)
            h_mat(2,2)=ff*h_mat(1,1);
        end
    end
    
    h_mat(2,2)=1/(h_mat(2,2)^2);
    h_mat(1,1)=1/(h_mat(1,1)^2);
    
%     h_mat(1,1)=1/(h_mat(1,1))^2;
%     h_mat(2,2)=1/(h_mat(2,2))^2;
%% 
%     h_min=1/(minimum_size)^2;
%     if h_mat(1,1)>h_min 
%         h_mat(2,2)=h_min;
%     elseif h_mat(2,2)>h_min
%         h_mat(1,1)=h_min;
%     end
%%    
    h_mat_out=mat*h_mat*mat_trans;
    eigen(i).map=[h_mat_out(1,1),h_mat_out(1,2),h_mat_out(2,2)];
end

end
